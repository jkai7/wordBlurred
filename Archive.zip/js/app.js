$(document).ready(function() {
  var myGame = new Game();
  myGame.pickRandom();

});
